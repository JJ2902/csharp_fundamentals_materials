﻿namespace CSharp.ifStatementsChallenge;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine(LeapYear.isLeapYear(2000));
        Console.WriteLine(LeapYear.isLeapYear(1970));
        Console.WriteLine(LeapYear.isLeapYear(1900));
        Console.WriteLine(LeapYear.isLeapYear(1988));
        Console.WriteLine(LeapYear.isLeapYear(1500));

    }
}
