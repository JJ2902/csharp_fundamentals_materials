using System;

namespace CSharp.ifStatementsChallenge{
    class LeapYear{
        int Year;

        public LeapYear(int Year)
        {
        this.Year = Year; 
        }

        //Method with if statement

        internal static bool isLeapYear(int Year){
            if (Year % 400 == 0){
                return true;
            } else if (Year % 100 == 0 && Year % 400 != 0){
                return false;
            } else if (Year % 4 == 0 && Year % 100 != 0){
                return true;
            } else if (Year % 4 != 0){
                return false;
            }
            return false;
        }
    }
}